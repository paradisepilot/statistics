### Name: interpp
### Title: Pointwise Bivariate Interpolation for Irregular Data
### Aliases: interpp interpp.old interpp.new
### Keywords: dplot

### ** Examples

data(akima)
# linear interpolation at points (1,2), (5,6) and (10,12)
akima.lip<-interpp(akima$x, akima$y, akima$z,c(1,5,10),c(2,6,12))



